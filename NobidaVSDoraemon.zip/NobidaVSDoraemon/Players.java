package NobidaVSDoraemon;

public class Players {
//����ֵ
	 int HP;
	//λ��
	 int playerX;
	 int playerY;
	
	public Players(int hp,int x,int y) {
		this.HP=hp;
		this.playerX=x;
		this.playerY=y;
	}
	public int getX() {
		return this.playerX;
	}
	public int getY() {
		return this.playerY;
	}
}
