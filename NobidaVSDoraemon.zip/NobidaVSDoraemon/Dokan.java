package NobidaVSDoraemon;

public class Dokan {
int x;
int y;
 public Dokan(int x,int y) {
	this.x=x;
	this.y=y;
 }
 //��ײ���
 public boolean penzhuang1(Players p1) {
	 return this.x+80>p1.playerX&&this.y+50>p1.playerY&&this.y+50<p1.playerY+200;
		 }
 
 public boolean penzhuang2(Players p2) {
	 return this.x<p2.playerX+100&&this.y+50>p2.playerY&&this.y+50<p2.playerY+200;
		 }
 //������Ļ���
 public boolean outof() {
	 return this.x<0||this.x>1000;
 }
}
