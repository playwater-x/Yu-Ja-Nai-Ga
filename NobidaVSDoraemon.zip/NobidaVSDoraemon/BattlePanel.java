package NobidaVSDoraemon;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.*;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class BattlePanel extends JPanel  {
     //Ѫ����
	 public xuetiao xuetiao1=new xuetiao(400,0,10);
	 public xuetiao xuetiao2=new xuetiao(400,600,10);
	//����
	 public Players dora=new Players(400,0,400);
	 public Players nobi=new Players(400,900,400);
	 public Dokan[] dokan=new Dokan[9];
	 public Dokan[] dokan1=new Dokan[9];
	//�ӵ�����
	 public int beenum1=1;
	 public int beenum2=1;
	 //����ָ��
	 public boolean shoot1=false;
	 public boolean shoot2=false;
	public BattlePanel() {
		
	
             //�������ӵ���ʼ��
		 for(int i=0;i<dokan.length;i++) {
				//dokan[i]=new Dokan(dora.playerX+110+i*100,dora.playerY+100);
				dokan[i]=new Dokan(-100,-100);
			}
		 for(int i=0;i<dokan1.length;i++) {
				//dokan1[i]=new Dokan(nobi.playerX+110+i*100,nobi.playerY+100);
				dokan1[i]=new Dokan(-100,-100);
			}
		 //ͼ�����
		 Icon icon1=new ImageIcon(this.getClass().getResource("images/dorawin.jpg"));
		 Icon icon2=new ImageIcon(this.getClass().getResource("images/nobiwin.jpg"));
		//���̼�����
		 this.setFocusable(true);
		addKeyListener(new KeyAdapter(){
			public void keyPressed(KeyEvent e){
				switch(e.getKeyCode()){
					case KeyEvent.VK_W:dora.playerY-=30;break;
					case KeyEvent.VK_S:dora.playerY+=30;break;
					case KeyEvent.VK_A:dora.playerX-=30;break;
					case KeyEvent.VK_D:dora.playerX+=30;break;
					case KeyEvent.VK_UP:nobi.playerY-=30;break;
					case KeyEvent.VK_DOWN:nobi.playerY+=30;break;
					case KeyEvent.VK_LEFT:nobi.playerX-=30;break;
					case KeyEvent.VK_RIGHT:nobi.playerX+=30;break;
					case KeyEvent.VK_J:shoot1=true;;
					if(beenum1>=1&&beenum1<=3) {
						dokan[beenum1-1].x=dora.getX()+100;
						dokan[beenum1-1].y=dora.getY()+100;
						beenum1+=1;
					}
					break;
					case KeyEvent.VK_N:shoot2=true;
					if(beenum2>=1&&beenum2<=3) {
						dokan1[beenum2-1].x=nobi.getX()-80;
						dokan1[beenum2-1].y=nobi.getY()+100;
						beenum2+=1;
					}
					break;
				}
				repaint();
			}
		});
	//�ӵ�timer
		Timer timer1 = new Timer(50,new ActionListener(){
			  public void actionPerformed(ActionEvent e){
				  	      if(shoot1==true) {
				  	    	  for(int i=1;i<beenum1;i++) {
				  	    		  dokan[i-1].x+=30;
				  	    		  if(dokan[i-1].penzhuang1(nobi)||dokan[i-1].outof()) {
				  	    			  if(dokan[i-1].outof()==false) {
				  	    				  xuetiao2.hptiao-=20;
				  	    				  xuetiao2.x+=20;
				  	    				  if(xuetiao2.hptiao==0) {
				  	    					  shoot1=false;
				  	    					  shoot2=false;
				  	    					JOptionPane.showMessageDialog(null,"Doraemon WIN",null,0,icon1);
				  	    					xuetiao2.hptiao=400;
				  	    					xuetiao2.x=600;
				  	    					xuetiao1.hptiao=400;
				  	    					dora.playerX=0;
				  	    					dora.playerY=400;
				  	    					nobi.playerX=900;
				  	    					nobi.playerY=400;
				  	    					
				  	    				  }
				  	    			  }
				  	    			  dokan[i-1].x=-100;
				  	    			  dokan[3]=dokan[i-1];
				  	    			  dokan[i-1]=dokan[beenum1-2];
				  	    			  dokan[beenum1-2]=dokan[3];
				  	    			  beenum1-=1;
				  	    			  
				  	    		  
				  	    		  }
				  	    	  }
				  	      }
				  	    if(shoot2==true) {
				  	    	  for(int i=1;i<beenum2;i++) {
				  	    		  dokan1[i-1].x-=30;
				  	    		  if(dokan1[i-1].penzhuang2(dora)||dokan1[i-1].outof()) {
				  	    			if(dokan1[i-1].outof()==false) {
				  	    				xuetiao1.hptiao-=20;
				  	    				if(xuetiao1.hptiao==0) {
				  	    					shoot1=false;
				  	    					shoot2=false;
				  	    					JOptionPane.showMessageDialog(null,"NOBIDA WIN",null,0,icon2);
				  	    					xuetiao2.hptiao=400;
				  	    					xuetiao2.x=600;
				  	    					xuetiao1.hptiao=400;
				  	    					dora.playerX=0;
				  	    					dora.playerY=400;
				  	    					nobi.playerX=900;
				  	    					nobi.playerY=400;
				  	    				
				  	    				}
				  	    			}
				  	    			  dokan1[i-1].x=-100;
				  	    			  dokan1[3]=dokan1[i-1];
				  	    			  dokan1[i-1]=dokan1[beenum2-2];
				  	    			  dokan1[beenum2-2]=dokan1[3];
				  	    			  beenum2-=1;
				  	    			 	  
				  	    		  }
				  	    	  }
				  	      }
						 repaint();
					  }
				  });
		timer1.start();
		
		
	}
	public void paint(Graphics g) {
		super.paint(g);
		paintxuetiao(g);
		paintPlayers(g);
		paintDokan(g);
	}
	public	void paintxuetiao(Graphics g) {
		g.setColor(Color.RED);
		g.fillRect(xuetiao1.x, xuetiao1.y, xuetiao1.hptiao, 30);
		g.fillRect(xuetiao2.x, xuetiao2.y, xuetiao2.hptiao, 30);
		g.setColor(Color.black);
		g.setFont(new Font("����",Font.BOLD,16));
		g.drawString("����A��   VS ���� ", 425, 40);
	}
	public void paintPlayers(Graphics g) {
		g.drawImage(new ImageIcon(this.getClass().getResource("images/dora1.jpg")).getImage(),dora.getX(),dora.getY(),null);
		g.drawImage(new ImageIcon(this.getClass().getResource("images/nobida2.jpg")).getImage(),nobi.getX(),nobi.getY(),null);
	}
	public void paintDokan(Graphics g) {
		if(shoot1==true) {
			for(int i=0;i<beenum1;i++) {
				g.drawImage(new ImageIcon(this.getClass().getResource("images/qidan1.jpg")).getImage(),dokan[i].x,dokan[i].y,null);
			}
		}
		if(shoot2==true) {
			for(int i=0;i<beenum2;i++) {
				g.drawImage(new ImageIcon(this.getClass().getResource("images/qidan2.jpg")).getImage(),dokan1[i].x,dokan1[i].y,null);
			}
		}
		
	}
	
}
