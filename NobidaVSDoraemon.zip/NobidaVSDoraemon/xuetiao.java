package NobidaVSDoraemon;

public class xuetiao {
     int hptiao;
     int x;
     int y;
     
     public xuetiao(int hp,int x,int y) {
    	 this.hptiao=hp;
    	 this.x=x;
    	 this.y=y;
    	 
     }
     
}
