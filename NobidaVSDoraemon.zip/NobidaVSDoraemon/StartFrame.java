package NobidaVSDoraemon;

import javax.swing.JFrame;

public class StartFrame extends JFrame{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
             BattlePanel p=new BattlePanel();
             JFrame frame=new JFrame();
             frame.add(p);
             frame.setSize(1000,900);
             frame.setLocationRelativeTo(null);
             frame.setVisible(true);
             frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
             
	}

}
